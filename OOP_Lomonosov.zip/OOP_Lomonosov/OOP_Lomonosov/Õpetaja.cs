﻿using OOP_Lomonosov;

public class Õpetaja : Isik, ITööline
{
    public string Aine { get; set; }
    public double Tunnitasu { get; set; }
    public int Tunnidkuus { get; set; }
    public TööTüüp VäljamakseTüüp { get; set; } = TööTüüp.Palk; // Õpetaja puhul on väljamakse tüüp alati palk

    public void Õpeta()
    {
        Console.WriteLine($"{Nimi} õpetab ainet: {Aine}.");
    }
    // override kirjutab abstraktse meetodi üle
    public override void Kirjelda()
    {
        Console.WriteLine($"Mina olen õpetaja {Nimi} ja ma õpetan: {Aine}.");
    }
    // ITööline liidese meetodi realiseerimine
    public double ArvutaPalk()
    {
        return Tunnitasu * Tunnidkuus;// Palk arvutatakse tunnitasu ja töötatud tundide korrutisena
    }
}
