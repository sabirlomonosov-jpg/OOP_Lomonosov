﻿using System;
using System.Collections.Generic;

namespace OOP_Lomonosov
{
    public class Program
    {
        public static void Main()
        {
            // Õpetaja
            Õpetaja õpetaja1 = new Õpetaja();
            õpetaja1.Nimi = "Eve";
            õpetaja1.Sünniaasta = 1980;
            õpetaja1.Aine = "Matemaatika";

            õpetaja1.Tervita();
            õpetaja1.Õpeta();
            õpetaja1.Kirjelda();

            Console.WriteLine("\n--- Õpilase andmed ---");

            // Õpilane
            Õpilane õpilane1 = new Õpilane();
            õpilane1.Nimi = "Markus";
            õpilane1.Sünniaasta = 2008;
            õpilane1.Kool = "Kutsehariduskeskus";
            õpilane1.Klass = 10;

            õpilane1.Tervita();
            õpilane1.Õpi();
            õpilane1.Kirjelda();

            // Koolihaldus
            Koolihaldus minuKool = new Koolihaldus();
            minuKool.LisaInimene(õpetaja1);
            minuKool.LisaInimene(õpilane1);

            // ITööline list
            List<ITööline> palgasaajad = new List<ITööline>();

            // 1. variant (käsitsi)
            Õpilane mati = new Õpilane();
            mati.Nimi = "Mati";
            mati.KeskmineHinne = 4.0;

            Õpilane kadi = new Õpilane
            {
                Nimi = "Kadi",
                Klass = 11,
                Kool = "Kutsehariduskeskus",
                KeskmineHinne = 3.5,
                Puudumised = 5,
                KasOnSotsTõend = false
            };

            Õpilane jüri = new Õpilane
            {
                Nimi = "Jüri",
                Klass = 12,
                Kool = "Kutsehariduskeskus",
                KeskmineHinne = 4.5,
                Puudumised = 35,
                KasOnSotsTõend = true
            };

            Õpetaja anna = new Õpetaja
            {
                Nimi = "Anna",
                Aine = "Python",
                Tunnitasu = 20,
                Tunnidkuus = 80
            };

            Õpetaja peeter = new Õpetaja
            {
                Nimi = "Peeter",
                Aine = "C#",
                Tunnitasu = 25,
                Tunnidkuus = 60
            };

            palgasaajad.AddRange(new ITööline[] { mati, kadi, jüri, anna, peeter });

            minuKool.LisaInimene(mati);
            minuKool.LisaInimene(kadi);
            minuKool.LisaInimene(jüri);
            minuKool.LisaInimene(anna);
            minuKool.LisaInimene(peeter);

            // 2. variant (tsükkel)
            Random rnd = new Random();

            string[] nimed = { "Maria", "Kati", "Juhan", "Anna", "Siim" };
            Õppevorm[] vormid = (Õppevorm[])Enum.GetValues(typeof(Õppevorm));

            for (int i = 0; i < nimed.Length; i++)
            {
                Õpilane õpilane = new Õpilane
                {
                    Nimi = nimed[rnd.Next(nimed.Length)],
                    Klass = rnd.Next(1, 13),
                    Kool = "TTHK",
                    KeskmineHinne = rnd.NextDouble() * 5,
                    Puudumised = rnd.Next(0, 350),
                    KasOnSotsTõend = rnd.Next(0, 2) == 1,
                    Staatus = vormid[rnd.Next(vormid.Length)]
                };

                palgasaajad.Add(õpilane);
                õpilane.Kirjelda();
                minuKool.LisaInimene(õpilane);
            }

            // Väljamaksed
            Console.WriteLine("--- Väljamaksed ---");

            foreach (ITööline isik in palgasaajad)
            {
                string tüüp = isik.VäljamakseTüüp.ToString();

                Console.WriteLine(
                    $" {tüüp}. Summa: {isik.ArvutaPalk()} eurot. {((Isik)isik).Nimi}le"
                );
            }

            minuKool.KuvaKõik();

            Console.ReadLine();
        }
    }
}